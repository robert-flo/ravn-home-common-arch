#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SYNC_BIN="${REPO_ROOT}/bin/ravn-home-sync"

echo "==> 1. Verificando sintaxis de scripts..."
bash -n "${SYNC_BIN}"
bash -n "${REPO_ROOT}/bash/rc"
echo "  [OK] Sintaxis bash valida."

echo "==> 2. Verificando ejecucion de ravn-home-sync con directorio temporal..."
TMP_DIR="$(mktemp -d /tmp/ravn-test-sync.XXXXXX)"
trap 'rm -rf "$TMP_DIR"' EXIT

TARGET_DIR="${TMP_DIR}/target_home"
mkdir -p "$TARGET_DIR"

# Test dry-run
echo "  [test] Dry-run..."
"${SYNC_BIN}" --target "$TARGET_DIR" --source "${REPO_ROOT}" --dry-run
if [[ -d "${TARGET_DIR}/.config" ]]; then
  echo "Error: Dry-run no deberia crear carpetas" >&2
  exit 1
fi
echo "  [OK] Dry-run no creo archivos."

# Test initial link run
echo "  [test] Primera ejecucion de enlace..."
OUTPUT1="$("${SYNC_BIN}" --target "$TARGET_DIR" --source "${REPO_ROOT}")"
echo "$OUTPUT1"

# Check created links
test -L "${TARGET_DIR}/.config/fcitx5/conf/classicui.conf"
test -L "${TARGET_DIR}/.config/gtk-3.0/settings.ini"
test -L "${TARGET_DIR}/.config/gtk-4.0/settings.ini"
test -L "${TARGET_DIR}/.config/gtk-4.0/gtk.css"
test -L "${TARGET_DIR}/.config/mpv/input.conf"
test -L "${TARGET_DIR}/.config/mpv/scripts"
echo "  [OK] Enlaces simbolicos creados correctamente."

# Test idempotency (second run must produce 0 changes)
echo "  [test] Segunda ejecucion (idempotencia)..."
OUTPUT2="$("${SYNC_BIN}" --target "$TARGET_DIR" --source "${REPO_ROOT}")"
echo "$OUTPUT2"

if echo "$OUTPUT2" | grep -E "Enlazado:|Respaldado:"; then
  echo "Error: La segunda ejecucion no fue idempotente!" >&2
  exit 1
fi
echo "  [OK] Idempotencia verificada: 0 cambios en segunda ejecucion."

# Test skeletons
echo "  [test] Verificando opcion --skeletons..."
"${SYNC_BIN}" --target "$TARGET_DIR" --source "${REPO_ROOT}" --skeletons
test -f "${TARGET_DIR}/.bashrc"
test -f "${TARGET_DIR}/.config/fish/config.fish"
test -f "${TARGET_DIR}/.config/alacritty/alacritty.toml"
test -f "${TARGET_DIR}/.config/mpv/mpv.conf"
echo "  [OK] Skeletons creados correctamente."

# Test idempotency of skeletons
OUTPUT3="$("${SYNC_BIN}" --target "$TARGET_DIR" --source "${REPO_ROOT}" --skeletons)"
if echo "$OUTPUT3" | grep -E "Creado loader:"; then
  echo "Error: Loader skeletons re-creados en segunda ejecucion!" >&2
  exit 1
fi
echo "  [OK] Idempotencia de skeletons verificada."

# Test --force on conflict
echo "  [test] Verificando conflicto y --force..."
rm -f "${TARGET_DIR}/.config/gtk-3.0/settings.ini" && echo "archivo conflictivo" > "${TARGET_DIR}/.config/gtk-3.0/settings.ini"
"${SYNC_BIN}" --target "$TARGET_DIR" --source "${REPO_ROOT}" --force
test -L "${TARGET_DIR}/.config/gtk-3.0/settings.ini"
ls "${TARGET_DIR}/.config/gtk-3.0/settings.ini.bak-"* > /dev/null
echo "  [OK] Conflicto resuelto con --force y respaldo generado."

echo "==> TODOS LOS TESTS PASARON EXITOSAMENTE."
